﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.model;

namespace WpfApp1.control
{
    internal class IdeiaInovacaoControle
    {
        private IdeiaInovacao ModeloPersistencia = new();

        public Boolean ControleCadastrarIdeiaInovacao(string area, string ideia, float custo)
        {

            ideia = ideia + "!!!!";

            IdeiaInovacao ii = new()
            {
                Area = area,
                Ideia = ideia,
                Custo = custo
            };

            if(ModeloPersistencia.CadastrarIdeiaInovacao(ii))
              return true; 
            return false;
        }
    }
}
