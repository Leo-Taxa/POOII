﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.persistencia;

namespace WpfApp1.model
{
    internal class IdeiaInovacao
    {
        public string Area { get; set; } = "";

        public string Ideia { get; set; } = "";

        public float Custo { get; set; } = 0;

        public Boolean CadastrarIdeiaInovacao(IdeiaInovacao i)
        {
            BD.SalvarDB(i);

            return true;
        }

        public override string? ToString()
        {
            return $"{Area} / {Ideia} / {Custo}";
            //return base.ToString();
        }
    }
}
