﻿using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.control;
using WpfApp1.persistencia;

namespace WpfApp1
{

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private IdeiaInovacaoControle objClasseII = new();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (!string.IsNullOrEmpty(TextBoxArea.Text) &&
                !string.IsNullOrEmpty(TextBoxDescricao.Text)) 
            {
                if (objClasseII.ControleCadastrarIdeiaInovacao(
                                                        TextBoxArea.Text,
                                                        TextBoxDescricao.Text,
                                                        float.Parse(TextBoxCusto.Text)))

                    MessageBox.Show("Cadastro realizado com sucesso");
            }
            else
            {
                MessageBox.Show("Campos devem ser preenchido!!!");
            }

            Debug.WriteLine("===========================");
            BD.RetornarBD().ForEach(x => Debug.WriteLine(x));
            Debug.WriteLine("===========================");

        }
    }
}